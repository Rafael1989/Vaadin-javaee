package pt.confidentia.rafael.ui.views.orderedit;

/**
 * Event object sent when an order has been updated.
 */
public class OrderUpdatedEvent {

	public OrderUpdatedEvent() {
		// This is just a marker class to invoke the correct listener
	}
}
