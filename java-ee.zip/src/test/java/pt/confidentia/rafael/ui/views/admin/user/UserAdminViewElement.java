package pt.confidentia.rafael.ui.views.admin.user;

import pt.confidentia.rafael.ui.views.admin.product.CrudViewElement;

public class UserAdminViewElement extends UserAdminViewDesignElement implements CrudViewElement {

}