package pt.confidentia.rafael.ui;

public class MainViewElement extends MainViewDesignElement {

}