package pt.confidentia.rafael.ui.views.admin.product;

public class ProductAdminViewElement extends ProductAdminViewDesignElement implements CrudViewElement {

}